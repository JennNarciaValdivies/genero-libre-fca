"use client";
import { useState } from "react";

export default function Home() {
  const [testimonial, setTestimonial] = useState("");
  const [scenario, setScenario] = useState(0);
  const scenarios = [
    {
      title: "Escenario 1: En clase",
      description: "Un profesor hace un comentario despectivo sobre personas no binarias. ¿Cómo reaccionas?",
      options: [
        "Ignoras el comentario para evitar conflictos",
        "Hablas con el profesor después de clase",
        "Levantas la mano y cuestionas el comentario con respeto"
      ]
    },
    {
      title: "Escenario 2: En grupo de trabajo",
      description: "Un compañero hace una broma sobre personas trans. ¿Qué haces?",
      options: [
        "Ríes con el grupo para no quedar mal",
        "Le explicas que esos comentarios refuerzan estereotipos dañinos",
        "No dices nada, pero lo comentas con alguien de confianza"
      ]
    },
    {
      title: "Escenario 3: Redes sociales",
      description: "Ves una publicación ofensiva compartida por un amigo. ¿Cuál sería tu reacción?",
      options: [
        "La ignoras y sigues navegando",
        "Le escribes por privado para explicarle por qué es ofensiva",
        "Comentas públicamente corrigiendo la información"
      ]
    }
  ];

  return (
    <main className="p-4 max-w-4xl mx-auto space-y-6">
      <h1 className="text-4xl font-bold text-center">Taller Interactivo: Identidad de Género</h1>
      <p className="text-center text-lg text-muted-foreground">
        Reflexiona con estos escenarios reales. ¿Cómo reaccionarías tú?
      </p>
      <div className="space-y-4">
        <h3 className="text-lg font-bold">{scenarios[scenario].title}</h3>
        <p>{scenarios[scenario].description}</p>
        <ul className="space-y-2">
          {scenarios[scenario].options.map((option, idx) => (
            <li key={idx}>
              <button className="w-full p-2 border rounded hover:bg-gray-100 text-left">
                {option}
              </button>
            </li>
          ))}
        </ul>
        {scenario < scenarios.length - 1 ? (
          <button
            onClick={() => setScenario(scenario + 1)}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded"
          >
            Siguiente escenario
          </button>
        ) : (
          <p className="text-green-600 font-semibold">
            ¡Gracias por reflexionar con nosotros! Comparte este taller con tus compañeros. ✨
          </p>
        )}
      </div>
    </main>
  );
}
